Hvordan programmet skal brukes:
gå på https://en.wikipedia.org/wiki/Main_Page og klikk på "Random article" i venstre margen
kopier linken til siden
kjør programmet og lim inn linken når du blir bedt om det
enjoy mens programmet finner alle sidene du går innom mens den klikker på første linken på siden til den kommer til science siden.